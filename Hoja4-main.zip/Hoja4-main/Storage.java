/*
Clase que relaciona Stacks y Listas, puesto que factory regresa la clase correspondiente
*/
public class Storage<T> {
    public Class Type() {// regresa la clase que es.
        return this.getClass();

    }

}
