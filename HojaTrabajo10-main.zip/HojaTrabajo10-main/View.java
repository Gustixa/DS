public class View {

    public void PrintCities() {
        System.out.println("0. Mixco:");
        System.out.println("1. Antigua: ");
        System.out.println("2. Escuintla: ");
        System.out.println("3. Santa Lucia: ");
        System.out.println("4. Guatemala: \n");
      }
}

    

    
    
    
    
    
    
    